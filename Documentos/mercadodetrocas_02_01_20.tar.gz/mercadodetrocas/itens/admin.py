from django.contrib import admin
from .models import Incluir_item

admin.site.register(Incluir_item)

# Register your models here.
