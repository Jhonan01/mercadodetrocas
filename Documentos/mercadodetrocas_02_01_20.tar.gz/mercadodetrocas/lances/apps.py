from django.apps import AppConfig


class LancesConfig(AppConfig):
    name = 'lances'
